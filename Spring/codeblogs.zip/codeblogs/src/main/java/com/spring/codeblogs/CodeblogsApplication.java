package com.spring.codeblogs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeblogsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeblogsApplication.class, args);
	}

}
