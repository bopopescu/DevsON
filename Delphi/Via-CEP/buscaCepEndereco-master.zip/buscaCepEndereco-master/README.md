# buscaCepEndereco
Exemplo de consulta de endereço com CEP ou consulta de CEP com o endereço usando o serviço ViaCep https://viacep.com.br/ (Delphi)

O Webservice tem um limite de requisições. Segundo o próprio ViaCep:"Ao constatar o uso de scripts de acesso massivo seu IP será automaticamente bloqueado por tempo indeterminado."
