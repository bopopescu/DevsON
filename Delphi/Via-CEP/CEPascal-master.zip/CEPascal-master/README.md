# CEPascal
O projeto __CEPascal__ faz consultas à API [ViaCEP](http://viacep.com.br), retornando um JSON com as informações.

![View this](gif/gif.gif)
