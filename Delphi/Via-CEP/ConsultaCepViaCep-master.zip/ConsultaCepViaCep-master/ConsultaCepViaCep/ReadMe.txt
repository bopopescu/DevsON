Informa��es:
Foi utilizado o Delphi 7 � componentes nativos, podendo ser compilado em qualquer vers�o do Delphi.
Paleta - Indy I/O Handlers: IdServerIOHandlerSSLOpenSSL
Paleta- Internet � XMLDocument
Foi retirado o IdHTTP porque � barrado pelo Anti-v�rus. 
