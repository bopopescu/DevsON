package com.br.devForProduct.gerProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
