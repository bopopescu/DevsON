package com.br.devForProduct.gerProduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerProductApplication.class, args);
	}

}
